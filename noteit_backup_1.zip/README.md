# Notit app





This code includes deployment settings for Firebase and Netlify in the `cors` directory:

| Service  	| Files                      	|
|----------	|----------------------------	|
| Firebase 	| firebase.json, .firebaserc 	|
| Netlify  	| _headers, _redirects       	|

If you're deploying this on another service, you'll need to set CORS headers appropriately for that service.
